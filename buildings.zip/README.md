# buildings

## LIVE DEMO:
### https://alikinvv.github.io/buildings/build/
### https://alikinvv.github.io/buildings/build/index-2.html
### https://alikinvv.github.io/buildings/build/index-3.html
### https://alikinvv.github.io/buildings/build/pay.html
### https://alikinvv.github.io/buildings/build/about.html
### https://alikinvv.github.io/buildings/build/contacts.html
### https://alikinvv.github.io/buildings/build/create.html
### https://alikinvv.github.io/buildings/build/create-2.html
### https://alikinvv.github.io/buildings/build/create-3.html
### https://alikinvv.github.io/buildings/build/create-4.html
### https://alikinvv.github.io/buildings/build/create-5.html
### https://alikinvv.github.io/buildings/build/goods.html
